﻿using System;

namespace EventosTec.Library
{
    public class Class1
    {
    }
}
