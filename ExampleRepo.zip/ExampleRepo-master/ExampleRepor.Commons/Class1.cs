﻿using System;

namespace ExampleRepor.Commons
{
    public class Class1
    {
    }
}
